class Profile < ActiveRecord::Base
	mount_uploader :media, AvatarUploader
	belongs_to :user
	validates_presence_of :city, :landmark, :address, :phone_numer, :pin_code, :name
	validates :phone_numer, :presence => {:message => 'Please enter valid phone number'}, :numericality => true, :length => {:minimum => 10, :maximum => 10}
	validates :pin_code, :presence => {:message => 'Please enter valid pin code'}, :numericality => true, :length => {:minimum => 4, :maximum => 6}
end
