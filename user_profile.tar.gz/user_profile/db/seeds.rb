# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
 User.create! :email => 'admin@gmail.com', :password => 'topsecret', :password_confirmation => 'topsecret', :is_admin => true
 Profile.create! :name => 'admin', :address => 'UE Address', :media => '5.jpeg', :city => 'Jalandhar/Punjab', :phone_numer => '1234567899', :landmark => 'NA',:pin_code => '123456', :user_id => '1'
