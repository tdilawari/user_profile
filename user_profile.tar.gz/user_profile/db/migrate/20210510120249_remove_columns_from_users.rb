class RemoveColumnsFromUsers < ActiveRecord::Migration
  def change
  	remove_column :users, :name, :string
    remove_column :users, :address, :text
    remove_column :users, :media, :string
  end
  create_table :profile do |t|
  	t.string :name
  	t.text :address
  	t.string :media
  end
end
