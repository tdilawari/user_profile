class AddCityColumnToProfile < ActiveRecord::Migration
  def change
  	add_column :profiles, :city, :string
  	add_column :profiles, :landmark, :string
  	add_column :profiles, :pin_code, :integer
  end
end
