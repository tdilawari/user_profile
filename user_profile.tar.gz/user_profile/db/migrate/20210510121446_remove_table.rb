class RemoveTable < ActiveRecord::Migration
  def change
  	drop_table :profile do |t|
  	t.string :name
  	t.text :address
  	t.string :media
  end
  end
end
