class CreateProfiles < ActiveRecord::Migration
  def change
    create_table :profiles do |t|
		t.string :name
		t.text :address
  		t.string :media	
      t.timestamps null: false
    end
  end
end
