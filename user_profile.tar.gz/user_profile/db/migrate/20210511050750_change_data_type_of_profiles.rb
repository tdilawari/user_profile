class ChangeDataTypeOfProfiles < ActiveRecord::Migration
  def change
  	change_column :profiles, :phone_numer, :string, limit: 10
  	change_column :profiles, :pin_code, :integer, limit: 4

  end
end
