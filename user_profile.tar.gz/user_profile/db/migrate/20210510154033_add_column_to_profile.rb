class AddColumnToProfile < ActiveRecord::Migration
  def change
  	add_column :profiles, :user_id, :integer
  	add_column :profiles, :phone_numer, :integer
  end
end
